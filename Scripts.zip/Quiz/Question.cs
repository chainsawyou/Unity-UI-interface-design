using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

[Serializable()]
public struct Answer
{
    [SerializeField] string _info;
    public string Info { get { return _info; } }

    [SerializeField] bool _isCorrect;
    public bool IsCorrect { get { return _isCorrect; } }
}

[CreateAssetMenu(fileName = "Question", menuName = "Quiz/new Question")]

public class Question : ScriptableObject
{
    public enum AnswerType { Multi,Single}

    [SerializeField] String _info = String.Empty;
    public String Info { get { return _info; } }

    [SerializeField] Answer[] _answers = null;
    public Answer[] Answers { get { return _answers; } }

    //Parameters

    [SerializeField] bool _useTimer = false;
    public bool UseTimer { get { return _useTimer; } }

    [SerializeField] int _time = 0;
    public int Timer { get { return _time; } }

    [SerializeField] AnswerType _answerType = AnswerType.Multi;
    public AnswerType GetAnswerType { get { return _answerType; } }

    [SerializeField] int _addScore = 10;
    public int AddScore { get { return _addScore; } }

    public List<int> GetCorrectAnswers()
    {
        List<int> CorrectAnswers = new List<int>();
        for (int i = 0; i < Answers.Length; i++)
        {
            if (Answers[i].IsCorrect)
            {
                CorrectAnswers.Add(i);
            }
        }
        return CorrectAnswers;
    }
}
