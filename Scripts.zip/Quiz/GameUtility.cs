public class GameUtility 
{
    public const float ResolutionDelayTime = 1;
    public const string SavePrefKey = "Game_Highscore_Value";
}
