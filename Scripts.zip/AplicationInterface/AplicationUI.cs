using UnityEngine;

public class AplicationUI : MonoBehaviour
{
    [SerializeField] Canvas BG;
    [SerializeField] Canvas interactive_UI;
    [SerializeField] Canvas image_UI;

    void Awake()
    {
        Canvas bg = GetComponentInChildren<Canvas>();
        Canvas interactive_ui = GetComponentInChildren<Canvas>();
        Canvas image_ui = GetComponentInChildren<Canvas>();

        bg.gameObject.SetActive(true);
    }

    public void ClickIn()
    {
        BG.gameObject.SetActive(false);
        interactive_UI.gameObject.SetActive(true); 
    }

    public void ClickToGenerateImage()
    {
        BG.gameObject.SetActive(false);
        interactive_UI.gameObject.SetActive(false);
        image_UI.gameObject.SetActive(true);
    }

    public void ClickBackToMainInterface()
    {
        BG.gameObject.SetActive(false);
        image_UI.gameObject.SetActive(false);
        interactive_UI.gameObject.SetActive(true);
    }


}

