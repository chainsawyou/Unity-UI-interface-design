using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class presentation_sys : MonoBehaviour
{
    [SerializeField] Text presentationText;
    [SerializeField] TextAsset textFile;
    [SerializeField] Sprite[] illustr_sprite = new Sprite[5];
    [SerializeField] Image current_Image;
    public int index;
    List<string> textList = new List<string>();
    bool isFinished = false;
    [SerializeField] float textSpeed = 0.1f;
    int countLine;
    int rawIndex = 0;

    void Awake()
    {
        GetTextFromAssestFile(textFile);
    }

    void Start()
    {
       // StartCoroutine(inputText());
    }

    void Update()
    {
        if(index < countLine)
        {
            UpdateLine();
        } 
        
    }

   public void ToBackText()
    {
        index--;
        if(rawIndex > 0)rawIndex--;
        if (index >= 0 && index < countLine)
        {
            presentationText.text = "";
            current_Image.sprite = illustr_sprite[rawIndex];
            isFinished = false;
        }
    }

    public void ToNextText()
    {
        if(index < countLine - 1)
        {
            index++;
            if(rawIndex < illustr_sprite.Length) rawIndex++;
            presentationText.text = "";
            current_Image.sprite = illustr_sprite[rawIndex];
            isFinished = false;
        }
    }


    void UpdateLine()
    {
        if (!isFinished)
        {
            //Debug.Log("Update:" + index);
            presentationText.text += textList[index];
            if (index == 2 || index == 5)
            {
                index += 1;
                presentationText.text += textList[index];
            }
            isFinished = true;
        }
    }

    void GetTextFromAssestFile(TextAsset file)
    {
        textList.Clear();
        index = 0;

        var textAmount = file.text.Split(new char[] {'\r' , '\n' }, System.StringSplitOptions.RemoveEmptyEntries);
        
        foreach(var textLine in textAmount)
        {
            textList.Add(textLine + "\n");
            countLine++;
            //Debug.Log("countLine:"+countLine);
        }
        textList.Add("");
        Debug.Log("countLine:" + countLine);
    }

    /*
    IEnumerator inputText()
    {
        presentationText.text = "";
        isFinished = false;
        //Debug.Log("inputtext:" + index);
        if (index != countLine  && !isFinished)
        {
            for (int i = 0; i < textList[index].Length; i++)
            {
                presentationText.text += textList[index][i];
                yield return new WaitForSeconds(textSpeed);
            }
        }
    }*/
    
}
