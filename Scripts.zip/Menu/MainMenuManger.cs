using UnityEngine.SceneManagement;
using UnityEngine;

public class MainMenuManger : MonoBehaviour
{
    public void LoadNextScene()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
    }

    public void QuitQuiz()
    {
        Application.Quit();
    }
}
